import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.Timer;

public class LinePanel extends JPanel {
	
	private Timer timer = new Timer(300,new TimerHandler());
	private int x=0;
	private int y=0;
	private int a=0;
	private int b=0;
	private int lines=100;
	private int color=0;
	
	Color colorArray[] = {Color.RED, Color.BLUE, Color.GREEN};
	
	/**
	 * Create the panel.
	 */
	public LinePanel() {
		timer.start();
	}
	
	private class TimerHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			repaint();		//calls method paintcomponent
		}
		
	}//end timer
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		Random random = new Random();
		
		for(int i=0;i<lines;i++) {  // to generate numbers within frames current size
			a = 1 + random.nextInt(this.getWidth());
			b = 1 + random.nextInt(this.getHeight());
			x = 1 + random.nextInt(this.getWidth());
			y = 1 + random.nextInt(this.getHeight());
			color = random.nextInt(colorArray.length);

			// draw a Line
			g.setColor(colorArray[color]);
//			g.drawLine(a, b, x, y);
			g.fillOval(a, b, x, y);
		}//
		
	}//end method paintcomponents
	

}//end class


