import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.GeneralPath;
import javax.swing.Timer;

public class StartPanel extends JPanel {

	private Timer timer = new Timer(30,new TimerHandler());
	private int x=0;
	private int y=0;
	
	/**
	 * Create the panel.
	 */
	public StartPanel() {
		timer.start();
	}
	
	private class TimerHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			repaint();		//calls method paintcomponent
		}
		
	}//end timer
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);//prevents graphics error
		Graphics2D g2d = (Graphics2D) g;

		// draw an Oval
//		g.setColor(Color.RED);
//		g.fillOval(100, 100, 100, 100);
//		g.setColor(Color.BLUE);
//		g.drawOval(100, 100, 100, 100);
		
		//coordinates for stars points
		int xPoints[]={65, 77, 119, 83, 93, 65, 37, 47, 11, 53};
		int yPoints[]={10, 46, 46, 64, 106, 82, 106, 64, 46, 46};
	
		GeneralPath star = new GeneralPath();
		star.moveTo(xPoints[0], yPoints[0]);
		
		//create star not draw it on panel yet
		for(int i=0;i<xPoints.length;i++){
			star.lineTo(xPoints[i], yPoints[i]);
		}
		star.closePath();
		
		g2d.translate(x++,y++); //move entire star
		g2d.setColor(Color.BLUE);
		g2d.fill(star);
		
		
	}//end method paintcomponents
	

}//end class
