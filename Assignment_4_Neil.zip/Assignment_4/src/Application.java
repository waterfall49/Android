import Animals.Animal;
import Animals.Penguin;
import Animals.SeaLion;
import Animals.Walrus;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class Application extends JFrame {
    private ReportController controller;

    private JLabel lblSpeciesName;
    private JList<String> lstSpecies;
    private JComboBox<String> comboGender;
    private JTextField txtWeight;
    private JTextField txtGPS;

    private JLabel lblBloodPressure;
    private JTextField txtBloodPressure;

    private JLabel lblSpots;
    private JTextField txtSpots;

    private JLabel lblDental;
    private JComboBox<String> comboDental;

    private JButton btnAdd;

    public Application() {
        this.setBounds(0, 0, 480, 450);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        controller = new ReportController();
    }

    public void run() {
        // --- Species Selector Panel ---
        JPanel pnlSpeciesSelector = new JPanel();
        pnlSpeciesSelector.setBounds(50, 50, 75, 100);
        pnlSpeciesSelector.setBorder(BorderFactory.createLineBorder(Color.black));
        pnlSpeciesSelector.setBackground(Color.white);

        JLabel lblComboHeader = new JLabel("Species");
        lblComboHeader.setBounds(50, 50, 100, 16);
        pnlSpeciesSelector.add(lblComboHeader);

        lstSpecies = new JList<>(new String[]{"Penguin", "Sea Lion", "Walrus"});
        lstSpecies.setBounds(lblComboHeader.getX() - 5, 70, 75, 55);
        lstSpecies.setBorder(BorderFactory.createLineBorder(Color.black));
        lstSpecies.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lstSpecies.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                resetInputDisplay();

                switch (lstSpecies.getSelectedIndex()) {
                    case 0:
                        lblSpeciesName.setText("Penguin");
                        lblBloodPressure.setVisible(true);
                        txtBloodPressure.setVisible(true);
                        break;
                    case 1:
                        lblSpeciesName.setText("Sea Lion");
                        lblSpots.setVisible(true);
                        txtSpots.setVisible(true);
                        break;
                    case 2:
                        lblSpeciesName.setText("Walrus");
                        lblDental.setVisible(true);
                        comboDental.setVisible(true);
                        break;
                }
            }
        });
        pnlSpeciesSelector.add(lstSpecies);

        this.add(pnlSpeciesSelector);

        JButton btnReport = new JButton("Report");
        btnReport.setBounds(pnlSpeciesSelector.getX(), pnlSpeciesSelector.getY() + pnlSpeciesSelector.getHeight() + 75, 75, 26);
        btnReport.addActionListener(e -> {
            controller.writeReport();
            //controller.readReport();
        });
        this.add(btnReport);

        // --- Species data input panel ---
        JPanel pnlSpeciesInput = new JPanel();
        pnlSpeciesInput.setBounds(lstSpecies.getX() + lstSpecies.getWidth() + 25, 50, 300, 300);
        pnlSpeciesInput.setBackground(Color.white);
        pnlSpeciesInput.setBorder(BorderFactory.createLineBorder(Color.black));
        pnlSpeciesInput.setLayout(null);

        int originPositionX = 10;
        int originPositionY = 25;

        JLabel lblSpecies = new JLabel("Species: ");
        lblSpecies.setBounds(originPositionX, originPositionY, 75, 16);
        pnlSpeciesInput.add(lblSpecies);

        lblSpeciesName = new JLabel();
        lblSpeciesName.setBounds(lblSpecies.getX() + lblSpecies.getWidth(), lblSpecies.getY(), 100, 16);
        pnlSpeciesInput.add(lblSpeciesName);

        JLabel lblGender = new JLabel("Gender: ");
        lblGender.setBounds(originPositionX, lblSpecies.getY() + lblSpecies.getHeight() + 25, 100, 16);
        pnlSpeciesInput.add(lblGender);

        comboGender = new JComboBox<>(new String[]{"Male", "Female"});
        comboGender.setBounds(lblGender.getX() + lblGender.getWidth(), lblGender.getY(), 100, 20);
        comboGender.setEnabled(false);
        pnlSpeciesInput.add(comboGender);

        JLabel lblWeight = new JLabel("Weight: ");
        lblWeight.setBounds(originPositionX, lblGender.getY() + lblGender.getHeight() + 25, 100, 16);
        pnlSpeciesInput.add(lblWeight);

        txtWeight = new JTextField();
        txtWeight.setBounds(lblWeight.getX() + lblWeight.getWidth(), lblWeight.getY(), 100, 20);
        txtWeight.setEnabled(false);
        pnlSpeciesInput.add(txtWeight);

        JLabel lblGPS = new JLabel("GPS: ");
        lblGPS.setBounds(originPositionX, lblWeight.getY() + lblWeight.getHeight() + 25, 100, 16);
        pnlSpeciesInput.add(lblGPS);

        txtGPS = new JTextField();
        txtGPS.setBounds(lblGPS.getX() + lblGPS.getWidth(), lblGPS.getY(), 150, 20);
        txtGPS.setEnabled(false);
        pnlSpeciesInput.add(txtGPS);

        // -- Species Specific elements
        // Penguins
        lblBloodPressure = new JLabel("Blood Pressure: ");
        lblBloodPressure.setBounds(originPositionX, lblGPS.getY() + lblGPS.getHeight() + 25, 100, 16);
        lblBloodPressure.setVisible(false);
        pnlSpeciesInput.add(lblBloodPressure);

        txtBloodPressure = new JTextField();
        txtBloodPressure.setBounds(lblBloodPressure.getX() + lblBloodPressure.getWidth(), lblBloodPressure.getY(), 100, 20);
        txtBloodPressure.setVisible(false);
        pnlSpeciesInput.add(txtBloodPressure);

        // Sea Lion
        lblSpots = new JLabel("Number of Spots: ");
        lblSpots.setBounds(originPositionX, lblGPS.getY() + lblGPS.getHeight() + 25, 105, 16);
        lblSpots.setVisible(false);
        pnlSpeciesInput.add(lblSpots);

        txtSpots = new JTextField();
        txtSpots.setBounds(lblSpots.getX() + lblSpots.getWidth(), lblSpots.getY(), 100, 20);
        txtSpots.setVisible(false);
        pnlSpeciesInput.add(txtSpots);

        // Walrus
        lblDental = new JLabel("Dental Health: ");
        lblDental.setBounds(originPositionX, lblGPS.getY() + lblGPS.getHeight() + 25, 100, 16);
        lblDental.setVisible(false);
        pnlSpeciesInput.add(lblDental);

        comboDental = new JComboBox<>(new String[]{"Good", "Average", "Poor"});
        comboDental.setBounds(lblDental.getX() + lblDental.getWidth(), lblDental.getY(), 100, 20);
        comboDental.setVisible(false);
        pnlSpeciesInput.add(comboDental);

        btnAdd = new JButton("Add");
        btnAdd.setBounds(pnlSpeciesInput.getWidth() / 3, txtGPS.getY() + (txtGPS.getHeight() * 2) + 60, 75, 25);
        btnAdd.setEnabled(false);
        btnAdd.addActionListener(e -> validateForm());
        pnlSpeciesInput.add(btnAdd);

        this.add(pnlSpeciesInput);

        // Leave me at the bottom
        this.setVisible(true);
    }

    private void resetInputDisplay() {
        lblBloodPressure.setVisible(false);
        txtBloodPressure.setVisible(false);
        txtBloodPressure.setText("");
        txtBloodPressure.setBorder(BorderFactory.createLineBorder(Color.black));

        lblSpots.setVisible(false);
        txtSpots.setVisible(false);
        txtSpots.setText("");
        txtSpots.setBorder(BorderFactory.createLineBorder(Color.black));

        lblSpeciesName.setText("");
        lblDental.setVisible(false);
        comboDental.setVisible(false);
        comboDental.setSelectedIndex(0);

        txtGPS.setText("");
        txtGPS.setEnabled(true);
        txtGPS.setBorder(BorderFactory.createLineBorder(Color.black));

        txtWeight.setText("");
        txtWeight.setEnabled(true);
        txtWeight.setBorder(BorderFactory.createLineBorder(Color.black));

        comboGender.setSelectedIndex(0);
        comboGender.setEnabled(true);

        btnAdd.setEnabled(true);
    }

    private void validateForm() {
        boolean isValid = true;

        if (txtWeight.getText().matches("[0-9]+"))
            txtWeight.setBorder(BorderFactory.createLineBorder(Color.green));
        else {
            isValid = false;
            txtWeight.setBorder(BorderFactory.createLineBorder(Color.red));
        }

        if (txtGPS.getText().matches("-?\\d+\\.\\d{6,8}\\s-?\\d+\\.\\d{6,8}"))
            txtGPS.setBorder(BorderFactory.createLineBorder(Color.green));
        else {
            isValid = false;
            txtGPS.setBorder(BorderFactory.createLineBorder(Color.red));
        }


        if (lstSpecies.getSelectedIndex() == 0) {
            if (txtBloodPressure.getText().matches("[0-9]+"))
                txtBloodPressure.setBorder(BorderFactory.createLineBorder(Color.green));
            else {
                isValid = false;
                txtBloodPressure.setBorder(BorderFactory.createLineBorder(Color.red));
            }
        } else if (lstSpecies.getSelectedIndex() == 1) {
            if (txtSpots.getText().matches("[0-9]+"))
                txtSpots.setBorder(BorderFactory.createLineBorder(Color.green));
            else {
                isValid = false;
                txtSpots.setBorder(BorderFactory.createLineBorder(Color.red));
            }
        }

        if (isValid) {
            String gender = comboGender.getSelectedIndex() == 0 ? "Male" : "Female";
            double weight = Double.parseDouble(txtWeight.getText());
            String gps = txtGPS.getText();

            if (lstSpecies.getSelectedIndex() == 0) {
                double bloodPressure = Double.parseDouble(txtBloodPressure.getText());
                controller.addAnimal("Penguin", gender, weight, gps, bloodPressure);
            } else if (lstSpecies.getSelectedIndex() == 1) {
                int spots = Integer.parseInt(txtSpots.getText());
                controller.addAnimal("Sea Lion", gender, weight, gps, spots);
            } else {
                String[] health = {"Good", "Average", "Poor"};
                String dentalHealth = health[comboDental.getSelectedIndex()];
                controller.addAnimal("Walrus", gender, weight, gps, dentalHealth);
            }
            resetInputDisplay();
        }
    }

    private void displayReport(String report){
        String[] lines = report.split("|");
        //Add to text area
    }
}