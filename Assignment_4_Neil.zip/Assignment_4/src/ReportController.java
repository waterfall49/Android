import Animals.*;

import java.io.*;
import java.util.ArrayList;

public class ReportController {
    private ArrayList<Animal> animals;


    public ReportController(){
        animals = new ArrayList<>();
    }

    public void addAnimal(String species, String gender, double weight, String gpsCoordinates,  double bloodPressure){
        this.animals.add(new Penguin(species, gender, weight, gpsCoordinates, bloodPressure));
    }

    public void addAnimal(String species, String gender, double weight, String gpsCoordinates,  int numSpots){
        this.animals.add(new SeaLion(species, gender, weight, gpsCoordinates, numSpots));
    }

    public void addAnimal(String species, String gender, double weight, String gpsCoordinates,  String dentalHealth){
        this.animals.add(new Walrus(species, gender, weight, gpsCoordinates, dentalHealth));
    }

    public void writeReport() {
        String report = readReport();

        for (Animal animal : animals) {
            report += "|" + animal.toString();
        }

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("animalReport.txt"));

            writer.write(report);
            writer.flush();
            writer.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private String readReport() {
        String report = "";

        try {
            BufferedReader reader = new BufferedReader(new FileReader("animalReport.txt"));

            report = reader.readLine();

            reader.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return report;
    }
}