package Animals;

public class Walrus extends Animal {
    private String dentalHealth;

    public Walrus(String species, String gender, double weight, String gpsCoordinates, String dentalHealth) {
        super(species, gender, weight, gpsCoordinates);
        this.dentalHealth = dentalHealth;
    }

    @Override
    public String toString() {
        return "Species: " + this.speciesName +
                ",Gender: " + this.gender +
                ",Weight: " + this.weight +
                ",GPS Coordinates: " + this.gps.get(0) +
                ",Dental Health: " + this.dentalHealth;
    }
}
