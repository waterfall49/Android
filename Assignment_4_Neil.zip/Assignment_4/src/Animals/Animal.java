package Animals;

public abstract class Animal {
    String speciesName;
    String gender;
    double weight;
    GPSDevice gps;

    Animal(String species, String gender, double weight, String gpsCoordinates) {
        gps = new GPSDevice();

        this.speciesName = species;
        this.gender = gender;
        this.weight = weight;
        this.gps.add(gpsCoordinates);
    }

    public abstract String toString();
}
