package Animals;

import java.util.ArrayList;

class GPSDevice {
     private ArrayList<String> coordinates;

     GPSDevice(){
        this.coordinates = new ArrayList<>();
    }

     void add(String coordinates){
        this.coordinates.add(coordinates);
    }

     String get(int position){
        return this.coordinates.get(position);
    }
}