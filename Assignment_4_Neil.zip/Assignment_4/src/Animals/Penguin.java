package Animals;

public class Penguin extends Animal {
    private double bloodPressure;

    public Penguin(String species, String gender, double weight, String gpsCoordinates, double bloodPressure) {
        super(species, gender, weight, gpsCoordinates);
        this.bloodPressure = bloodPressure;
    }

    @Override
    public String toString() {
        return "Species: " + this.speciesName +
                ",Gender: " + this.gender +
                ",Weight: " + this.weight +
                ",GPS Coordinates: " + this.gps.get(0) +
                ",Blood Pressure: " + this.bloodPressure;
    }
}
