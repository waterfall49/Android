package Animals;

public class SeaLion extends Animal {
    private int numberOfSpots;

    public SeaLion(String species, String gender, double weight, String gpsCoordinates, int numSpots) {
        super(species, gender, weight, gpsCoordinates);
        this.numberOfSpots = numSpots;
    }

    @Override
    public String toString() {
        return "Species: " + this.speciesName +
                ",Gender: " + this.gender +
                ",Weight: " + this.weight +
                ",GPS Coordinates: " + this.gps.get(0) +
                ",Number of Spots: " + this.numberOfSpots;
    }
}
