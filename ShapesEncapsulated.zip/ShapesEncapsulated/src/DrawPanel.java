import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.awt.event.*;

public class DrawPanel extends JPanel {
	
	Timer timer = new Timer(300,new TimerHandler());
	//here is where upcast to list happens 
	
	private Oval myOval = new Oval();
	private CircleStar cs = new CircleStar();
	
	public DrawPanel() { //default constructor
		timer.start();
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		this.setBackground(Color.WHITE);
//		System.out.println("tick");
		//call to shape objects draw method
	
		
		//myOval.draw(g, this); //call myself
		//myShapeList[i].draw();//late bind
		
		cs.draw(g, this);
	}
	
	private class TimerHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			repaint(); //calls paint component			
		}
		
	}//end named inner class TimerHandler

}//end JPanel
