import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.awt.event.*;

public class Oval {
	
	private Random random = new Random();
	private Color colorArray[] = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.BLACK, Color.MAGENTA};
	private int color = 0;
	private int a = 0; //coord #1
	private int b = 0;
	private int x = 0; //coord #2
	private int y = 0;
	
	public void draw(Graphics g, DrawPanel dp) {
		a = 1 + random.nextInt(dp.getWidth());
		b = 1 + random.nextInt(dp.getHeight());
		x = 1 + random.nextInt(dp.getWidth());
		y = 1 + random.nextInt(dp.getHeight());
		
		color = 0 + random.nextInt(colorArray.length);
		g.setColor(colorArray[color]);
		g.fillOval(a, b, x, y);
	}//end draw
	
}//end class
