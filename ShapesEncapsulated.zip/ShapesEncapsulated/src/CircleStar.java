import javax.swing.*;
import java.awt.*;
import java.util.Random;
import java.awt.event.*;
import java.awt.geom.GeneralPath;

public class CircleStar { 
	
	private Random random = new Random(); 
	
	public void draw(Graphics g, DrawPanel dp) { 
		//drawing code goes here 
        int xPoints[] = { 55, 67, 109, 73, 83, 55, 27, 37, 1, 43}; 
        int yPoints[] = { 0, 36, 36, 54, 96, 72, 96, 54, 36, 36}; 
        int v1 =0; 
        int v2 =0; 
        
        
        Graphics2D g2d = (Graphics2D) g; 
        GeneralPath star = new GeneralPath(); 
        
        star.moveTo( xPoints[0], yPoints[0] ); 
        
        //create the star--this does not draw the start
        
        for (int count = 1; count < xPoints.length; count++) 
            star.lineTo(xPoints[count], yPoints[count]); 
        
        star.closePath(); 
        v1++;	 
        v2++;  
        
//        g2d.translate(v1, v2); 
        g2d.translate(200, 200);
        
        
        for(int count = 1; count <= 20; count++)
        {
            g2d.rotate( Math.PI / 10.0);
            
            g2d.setColor(new Color (random.nextInt(256), random.nextInt(256), random.nextInt(256)));
            
            g2d.fill(star);
        }//end for

	}//end draw
	

}//end class
