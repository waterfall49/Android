import javax.swing.JPanel;
import java.awt.*;
import java.awt.geom.*;
import java.awt.geom.Rectangle2D.Double;
import java.awt.image.BufferedImage;
import java.awt.Image.*; //buffered image


public class drawPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public drawPanel() {
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 10, 10);
		add(panel);
	}
	
	@Override public void paintComponent(Graphics g) {
		super.paintComponent(g); //prevents some graphics issues
		Graphics2D g2d = (Graphics2D) g;
		
		//Shape #1
		g2d.setPaint(Color.RED);
		g2d.draw(new Rectangle2D.Double(80,30,65,100));
		
		//Shape #2
		g2d.setPaint(new GradientPaint(5,30,Color.BLUE, 35,100,Color.YELLOW,true));
		g2d.fill(new Ellipse2D.Double(0,0,60,60));
		
		//Shape #3
		// buffer is where you create complex paint
		BufferedImage buffImage = new BufferedImage(10,10,BufferedImage.TYPE_INT_RGB);
		Graphics2D gg = buffImage.createGraphics();
		gg.setColor(Color.YELLOW);
		gg.fillRect(0, 0, 10, 10);
		gg.setColor(Color.BLACK);
		gg.drawRect(1, 1, 6, 6);
		gg.setColor(Color.BLUE);
		gg.fillRect(1, 1, 6, 6);
		gg.setColor(Color.RED);
		gg.fillRect(4, 4, 3, 3);
		
		g2d.setPaint(new TexturePaint(buffImage,new Rectangle(10,10)));
		g2d.fill(new RoundRectangle2D.Double(155, 30, 75, 100, 50, 50));
		
		//Shape #4
		g2d.setPaint(Color.BLACK);
		g2d.setStroke(new BasicStroke(6.0f));
		g2d.draw(new Arc2D.Double(240, 30, 70, 100, 0, 270, Arc2D.PIE));
		
		//Shape #5
		g2d.setPaint(Color.GREEN);
		g2d.draw(new Line2D.Double(395, 30, 320, 150));
		float dashes[] = {10};
		g2d.setPaint(Color.YELLOW);
		g2d.setStroke(new BasicStroke(4,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND,10,dashes,0));
		g2d.draw(new Line2D.Double(320, 30, 395, 150));
		
	}
}//end class
